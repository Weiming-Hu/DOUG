/* 
 * File:   AnEn.h
 * Author: Guido Cervone
 *         Weiming Hu (weiming@psu.edu)
 *
 * Created on January 25, 2018, 10:05 AM
 */

/*! \mainpage CAnalogsV2 Libraries and Application for C++ and R
 *
 * CAnalogsV2 libraries and applications provide algorithms and
 * interfaces in C++ and R language to compute Analog Ensembles.
 *
 */

#ifndef ANEN_H
#define ANEN_H

#include "Functions.h"
#include "Ensemble.h"
#include "ColorSetting.h"

#include <numeric>
#include <algorithm>
#include <string>
#include <vector>
#include <fstream>
#include <cmath>
#include <map>

// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::plugins(openmp)]]
//
#ifdef _OPENMP
#include <omp.h>
#else
#ifndef omp_get_thread_num
#define omp_get_thread_num() 0
#endif

#ifndef omp_get_num_threads
#define omp_get_num_threads() 1
#endif

#endif

// AnEn is derived from the class Ensemble for the purpose
// of Analog Ensemble calculation
//

class AnEn : public Ensemble {
public:
    AnEn();
    
    // no copy constructor
    AnEn(const AnEn& orig) = delete;
    
    AnEn(std::vector <double> const & weights,
            std::size_t observation_ID,
            std::vector < std::size_t > const & main_stations_ID,
            std::size_t test_ID_start, std::size_t test_ID_end,
            std::size_t search_ID_start, std::size_t search_ID_end,
            std::size_t members_size = 10,
            int rolling = 0,
            bool quick = true,
            std::size_t num_cores = 1,
            bool search_extension = false,
            bool observation_from_extended_station = false,
            bool recompute_sd_for_extended_station = false,
            std::string output_metric = "");

    virtual ~AnEn();
    
    // enumerations for metric columns.
    // the metric has 3 columns for values,
    // stations, and day
    //
    static const unsigned int _index_VAL = 0;
    static const unsigned int _index_STATION = 1;
    static const unsigned int _index_DAY = 2;
   
    
        
    // overload the pure virtual method Ensemble::computeAnalogs
    Array5D computeAnalogs(
            const Array4D & forecasts,
            const Array4D & observations
            ) const override;

    bool validate_parameters(
            const Array4D & forecasts,
            const Array4D & observations) const;



    bool switch_observation_from_extended_station(bool b);
    
    bool switch_save_search_stations(bool input);

    bool switch_recompute_sd_for_extended_station(bool b);

    bool switch_search_extension(bool b);
    
    bool set_output_metric(string input);

    bool set_distance(double input);

    bool set_num_nearest(size_t input);

    double get_distance();

    size_t get_num_nearest();

    // get the extended stations to search for the current
    // main station ID
    //
    std::vector<size_t> getStationExtension(
            const Array4D & array,
            const size_t & main_station_ID) const;

    bool select_stations_within_distance(
            const Array4D & array,
            const size_t & main_station_ID,
            vector<size_t> & search_stations_ID) const;

    bool select_stations_within_square(
            const Array4D & array,
            const size_t & main_station_ID,
            vector<size_t> & search_stations_ID,
            const double & edge) const;

    bool select_nearest_stations(
            const Array4D & array,
            const size_t & main_station_ID,
            vector<size_t> & saerch_stations_ID) const;

protected:
    bool computeMetricSingle_(
            Array4D const & forecasts,
            Array4D const & observations,
            Array2D sds, // no reference because it might need recomputing
            std::size_t main_station_ID,
            std::size_t extended_station_ID,
            std::size_t search_ID,
            std::size_t test_ID,
            int time, int begin_time, int end_time,
            std::vector<double> & metric) const;

    bool computeSds_(
            const Array4D & forecasts,
            const std::size_t & main_station_ID,
            Array2D & sds) const;

private:
    // whether the stations in forecasts and observations are
    // ordered by column
    // this is crucial for calculating the row and col numbers
    // based on the station index number
    //bool by_col_;

    // whether to take observations from the extended station
    bool observation_from_extended_station_ = false;

    // whether to recompute standard deviation when calculating
    // metrics over extended stations
    //
    bool recompute_sd_for_extended_station_ = false;

    // whether to search the extended stations
    bool search_extension_ = false;

    // a folder path is needed for output metric files
    //
    std::string output_metric_ = "";

    // Size of the last dimension in the Array5D return type.
    // It includes the member values, the day index and the
    // station index of the member.
    //
    // This should not be changed!
    //
    static const size_t _fifth_dimension = 3;

    // when search extension is used,
    // specify distance the search of nearby stations
    //
    double distance_ = 0.0;

    // when search extension is used, specify num_nearest
    // for the number of nearest neighbors to take.
    //
    size_t num_nearest_ = 0;
    
    // whether to save the search stations for each main
    // station
    //
    bool save_search_stations_ = false;
    
    // enumerations for metric columns.
    // the metric has 3 columns for values,
    // stations, and day
    //
    static const unsigned int _Metric_VAL_ = 0;
    static const unsigned int _Metric_STATION_ = 1;
    static const unsigned int _Metric_DAY_ = 2;
    
};

// overload operator<< for vector
// this is for the convenience of debug_out for vectors
//
// Because it doesn't access class members
// so it doesn't need to be included in the class declaration
//

template<typename T>
std::ostream & operator<<(ostream& out, const vector<T>& v) {
    out << "[ ";
    for (const auto& i : v) {
        cout << i << " ";
    }
    out << "]";
    return out;
};


#endif
