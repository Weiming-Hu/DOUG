# "`-''-/").___..--''"`-._
#  (`6_ 6  )   `-.  (     ).`-.__.`)   WE ARE ...
#  (_Y_.)'  ._   )  `._ `. ``-..-'    PENN STATE!
#    _ ..`--'_..-_/  /--'_.' ,'
#  (il),-''  (li),'  ((!.-'
# 
# Author: Weiming Hu <wuh20@psu.edu>
#         Geoinformatics and Earth Observation Laboratory (http://geolab.psu.edu)
#         Department of Geography and Institute for CyberScience
#         The Pennsylvania State University

#' RAnEn::print.AnEn
#' 
#' @author Weiming Hu \email{weiming@@psu.edu}
#' 
#' Overload print function for class AnEn
#' 
#' @param x an AnEn object
#' 
#' @examples 
#' AnEn <- list()
#' class(AnEn) <- 'AnEn'
#' print(AnEn)
#' 
#' @export
print.AnEn <- function (x) {
  cat("Class: AnEn list\n")
  empty <- T
  
  if ('analogs' %in% names(x)) {
    empty <- F
    cat("Member 'analogs': [station][day][flt][member][type] ")
    cat(dim(x$analogs))
    cat("\n")
  }
  
  if ('metrics' %in% names(x)) {
    empty <- F
    cat("Member 'metrics': length [")
    cat(length(x$metrics))
    cat("]\n")
  }
  
  if ('search_stations' %in% names(x)) {
    empty <- F
    cat("Member 'search_stations': length [")
    cat(length(x$search_stations))
    cat("]\n")
  }
  
  if ('bias.corrected.analogs' %in% names(x)) {
    empty <- F
    cat("Member 'bias.corrected.analogs': [station][day][flt][member][type] ")
    cat(dim(x$bias.corrected.analogs))
    cat("\n")
  }
  
  if ('bias' %in% names(x)) {
    empty <- F
    cat("Member 'bias': [station][day][flt] ")
    cat(dim(x$bias))
    cat("\n")
  }
  
  if (empty) {
    cat('[empty list]\n')
  }
}
