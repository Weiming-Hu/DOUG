/* 
 * File:   Ensemble.h
 * Author: Guido Cervone
 *         Weiming Hu (weiming@psu.edu)
 *
 * Created on October 4, 2013, 12:15 AM
 */

#ifndef ENSEMBLE_H
#define ENSEMBLE_H

#include "Array4D.h"
#include "Array5D.h"

// This is a generic class for the analog ensemble. 
// It contains pure virtual methods that must be overwritten in child classes.
//

class Ensemble {
public:

    Ensemble();

    Ensemble(
            std::vector <double> const & weights,
            std::size_t observation_ID,
            std::vector < std::size_t > const & main_stations_ID,
            std::size_t test_ID_start, std::size_t test_ID_end,
            std::size_t search_ID_start, std::size_t search_ID_end,
            std::size_t members_size,
            int rolling, bool quick,
            std::size_t num_cores
            ) : weights_(weights), observation_ID_(observation_ID),
    main_stations_ID_(main_stations_ID),
    test_ID_start_(test_ID_start), test_ID_end_(test_ID_end),
    search_ID_start_(search_ID_start), search_ID_end_(search_ID_end),
    members_size_(members_size), rolling_(rolling),
    quick_(quick), num_cores_(num_cores) {
        if (rolling < 0) {
            search_ID_end_ = test_ID_start_ + rolling_;
        }
    };

    virtual ~Ensemble();

    virtual Array5D computeAnalogs(
            const Array4D & forecasts,
            const Array4D & observations
            ) const = 0;

    bool validate_parameters(
            const Array4D & forecasts,
            const Array4D & observations) const;

protected:
    // The weights to use in the computations
    std::vector <double> weights_;

    // The parameter for which we perform the analogs
    std::size_t observation_ID_;

    // For which stations should we perform the analogs
    std::vector < std::size_t > main_stations_ID_;

    // the days for which we do the test (verification)
    std::size_t test_ID_start_;
    std::size_t test_ID_end_;

    // the days for which we perform the analogs
    std::size_t search_ID_start_;
    std::size_t search_ID_end_;

    // how many members to keep
    std::size_t members_size_ = 10;

    // This indicates that the search / testing are rolling as in an operational sense
    int rolling_ = 0;

    // Use quick sort algorithm
    bool quick_ = true;

    // the number of cores to use
    std::size_t num_cores_ = 1;
};

#endif
