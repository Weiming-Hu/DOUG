/* 
 * File:   Array2D.cpp
 * Author: Guido Cervone
 *         Weiming Hu
 * 
 * Created on October 1, 2013, 9:00 AM
 */

#include "Array2D.h"
#include "ColorSetting.h"

#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

Array2D::Array2D() {
    //cout << "Array2D Constructor: Default" << endl;
    resize(1);
    (*this)[0].resize(1, 0.0);
}

Array2D::Array2D(size_t d1, size_t d2) {

    //cout << "Array2D Constructor: With Dimensions" << endl;
    resize(d1);

    vector< vector < double > >::iterator iter;

    for (iter = begin(); iter < end(); iter++) {
        iter->resize(d2, 0.0);
    }

}

Array2D::Array2D(Array2D const & rhs) : vector < vector < double > >(rhs) {
    //cout << "Array2D Constructor: Copy" << endl;
    *this = rhs;
}

Array2D::~Array2D() {
    //cout << "Array2D Destructor" << endl;
}

Array2D & Array2D::operator=(const Array2D &rhs) {
    
    if (this != &rhs) {
        try {
            size_t dimM = rhs.sizeM();
            size_t dimN = rhs.sizeN();

            this->resize(dimM);

            for (size_t m = 0; m < dimM; m++) {
                (*this)[m].resize(dimN);

                for (size_t n = 0; n < dimN; n++) {
                    (*this)[m][n] = rhs[m][n];
                }
            }
        } catch (std::bad_alloc e) {
            cerr << BOLDRED << "ERROR: insufficient memory while resizing!"
                << RESET << endl;
            throw e;
        }
    }

    return *this;
}

void
Array2D::randomize() {

    auto M = sizeM();
    auto N = sizeN();

    for (size_t m = 0; m < M; m++) {
        for (size_t  n = 0; n < N; n++) {
            // pseudo-random is good enough
            // no need to set seeds in each loop
            //
            //std::srand(std::time(0));
            (*this)[m][n] = std::rand();
        }
    }
}

void
Array2D::print_size(ostream & os) const {

    auto M = sizeM();
    auto N = sizeN();

    os << "[" << M << ", "
        << N << "]" << endl;
}

void
Array2D::print(ostream & os) const {

    os << "Array Shape = ";
    os << "[ " << sizeM() << " ][ " << sizeN() << " ]" << endl;

    os << endl;

    auto M = sizeM();
    auto N = sizeN();

    for (size_t m = 0; m < M; m++) {
        for (size_t n = 0; n < N; n++) {
            os << (*this)[m][n] << "\t";
        }
        os << endl;
    }
}

void
Array2D::print_dim(ostream & os, size_type m) const {

    auto N = sizeN();

    for (size_type n = 0; n < N; n++) {
        os << (*this)[m][n] << "\t";
    }
    os << endl;
}

ostream &
operator<<(ostream & os, Array2D const & bv) {

    bv.print(os);

    return os;
}

Array2DCompare::Array2DCompare(size_t column)
: m_column_(column) {
}


bool
Array2DCompare::operator()(vector <double> const& lhs,
        vector <double> const& rhs) {

    if (std::isnan(lhs[m_column_])) return false;
    if (std::isnan(rhs[m_column_])) return true;

    return lhs[m_column_] < rhs[m_column_];
}
