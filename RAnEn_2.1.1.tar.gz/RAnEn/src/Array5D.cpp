/*
 * Author: Weiming Hu
 *
 * Created on June 3, 2016
 *
 */

#include "Array5D.h"
#include <iomanip> //  for std::setprecision()

Array5D::Array5D() {

}

Array5D::Array5D(const Array5D & rhs) {
    *this = rhs;
}

Array5D::Array5D(
        size_t num_stations, size_t num_days,
        size_t num_flts, size_t num_members,
        size_t num_returns) :
num_stations_(num_stations),
num_days_(num_days),
num_flts_(num_flts),
num_members_(num_members),
num_returns_(num_returns) {
    // Array5D standard constructor
    //
    resize(boost::extents
            [num_stations_]
            [num_days_]
            [num_flts_]
            [num_members_]
            [num_returns_]);
}

Array5D::~Array5D() {

}

void
Array5D::print(std::ostream & os) const {
    os << "Array Shape = ";
    for (index i = 0; i < 5; i++) {
        os << "[" << shape()[i] << "]";
    }
    os << std::endl;

    auto M = shape()[0];
    auto N = shape()[1];
    auto O = shape()[2];
    auto P = shape()[3];
    auto Q = shape()[4];


    for (size_t m = 0; m < M; m++) {
        for (size_t n = 0; n < N; n++) {
            os << "[ " << m << ", " << n << ", , ,]" << std::endl << "\t";

            for (size_t p = 0; p < P; p++) {
                os << "\t[,,," << p << ", ]";
            }
            os << std::endl;

            for (size_t o = 0; o < O; o++) {
                os << "[,," << o << ",, ]\t";

                for (size_t p = 0; p < P; p++) {
                    os << "( ";
                    for (size_t q = 0; q < Q; q++) {
                        os << std::setprecision(3) << ((*this)[m][n][o][p][q]) << " ";
                    }
                    os << ")";
                    if (p < (P - 1)) {
                        os << ",\t";
                    }
                }
                os << std::endl;
            }
            os << std::endl;
        }
        os << std::endl;
    }
}

std::ostream &
operator<<(std::ostream & os, const Array5D & arr) {
    arr.print(os);
    return os;
}

bool
Array5D::reformat_array(Array5D & refmt, std::string type = "all") {
    // reformat the Array5D according to the parameter type

    typedef boost::multi_array_types::index_range range;

    if (type == "station_day") {
        refmt.resize(boost::extents
                [this->shape()[0]]
                [this->shape()[1]]
                [this->shape()[2]]
                [this->shape()[3]]
                [static_cast<int> (Member::STATION)]);
        Array5D::array_view<5>::type view =
                (*this)[ boost::indices[range()][range()]
                [range()][range()][range(1, 3)] ];
        refmt = view;
        return true;
    }

    if (type == "all") {
        refmt.resize(boost::extents
                [this->shape()[0]]
                [this->shape()[1]]
                [this->shape()[2]]
                [this->shape()[3]]
                [this->shape()[4]]);
        refmt = (*this);
        return true;
    }

    refmt.resize(boost::extents
            [this->shape()[0]]
            [this->shape()[1]]
            [this->shape()[2]]
            [this->shape()[3]]
            [static_cast<int> (Member::VAL)]);

    Array5D::array_view<4>::type view_refmt =
            refmt[ boost::indices[range()][range()][range()][range()][0] ];

    if (type == "value") {
        Array5D::array_view<4>::type view =
                (*this)[
                boost::indices[range()][range()]
                [range()][range()][static_cast<int> (Member::VAL)] ];
        view_refmt = view;
        return true;
    }

    if (type == "day_index") {
        Array5D::array_view<4>::type view =
                (*this)[ boost::indices[range()][range()]
                [range()][range()][static_cast<int> (Member::DAY)]];
        view_refmt = view;
        return true;
    }

    std::cerr << "Parameter type (" << type << ") not recognized." << std::endl;
    return false;
}

bool
Array5D::set_xs(std::vector<double> input) {
    if (input.size() == this->shape()[0]) {
        // if there are enough xs for stations
        xs_ = input;
        return true;
    } else {
        std::cerr << "Error: the length of input (" << input.size()
                << ") should equal to the number of stations ("
                << this->shape()[0] << ")!" << std::endl;
        return false;
    }
}

bool
Array5D::set_ys(std::vector<double> input) {
    if (input.size() == this->shape()[0]) {
        // if there are enough ys for stations
        ys_ = input;
        return true;
    } else {
        std::cerr << "Error: the length of input (" << input.size()
                << ") should equal to the number of stations ("
                << this->shape()[0] << ")!" << std::endl;
        return false;
    }
}

std::ostream &
Array5D::print_search_stations(ostream& out) {

    out << "main station index\ttotal number of search stations\tsearch stations ID"
            << endl << endl;

    for (size_t d1 = 0; d1 < vec_search_stations_.size(); d1++) {
        out << d1 << "\t" << vec_search_stations_[d1].size() << "\t[ ";
        for (auto i : vec_search_stations_[d1]) {
            out << i << " ";
        }
        out << "]" << endl;
    }

    return out;
}

std::vector<double>
Array5D::get_xs() {
    return xs_;
}

std::vector<double>
Array5D::get_ys() {
    return ys_;
}

bool
Array5D::empty_xs() {
    return xs_.empty();
}

bool
Array5D::empty_ys() {
    return ys_.empty();
}

size_t
Array5D::xs_size() const {
    return xs_.size();
}

size_t
Array5D::ys_size() const {
    return ys_.size();
}

bool
Array5D::set_search_stations(
        size_t main_station_index,
        const std::vector<size_t> & search_stations) {
    vec_search_stations_.at(main_station_index).resize(search_stations.size(), 0);
    for (size_t i = 0; i < search_stations.size(); i++) {
        vec_search_stations_[main_station_index][i] = search_stations[i];
    }
    return true;
}

bool
Array5D::set_metric(
        size_t main_station_index,
        size_t test_ID,
        size_t flt,
        const Array2D & metric) {
    this->metrics_[main_station_index][test_ID][flt] = metric;
    return true;
}

bool
Array5D::resize_vec_search_stations() {
    vec_search_stations_.resize(num_stations_);
    return true;
}

const boost::multi_array<Array2D, 3> &

Array5D::get_const_metrics() const {
    return metrics_;
}

const std::vector< std::vector<size_t> > &
Array5D::get_const_vec_search_stations() const {
    return vec_search_stations_;
}

bool
Array5D::resize_metrics() {
    metrics_.resize(boost::extents
            [num_stations_]
            [num_days_]
            [num_flts_]);
    return true;
}
