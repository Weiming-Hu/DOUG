/* 
 * File:   Ensemble.cpp
 * Author: Weiming Hu (weiming@psu.edu)
 * 
 * Created on January 25, 2018, 3:40 PM
 */

#include "Ensemble.h"
#include "ColorSetting.h"

Ensemble::Ensemble() {
}

Ensemble::~Ensemble() {
}

bool
Ensemble::validate_parameters(
        const Array4D& forecasts,
        const Array4D& observations) const{
    
    if (test_ID_start_ > test_ID_end_) {
        std::cerr << BOLDRED << "ERROR: test_ID_start (" << test_ID_start_
                << ") is greater than test_ID_end ("
                << test_ID_end_ << ")!" << RESET << std::endl;
        return false;
    }

    if (test_ID_end_ >= forecasts.getSizeDim2()) {
        std::cerr << BOLDRED << "ERROR: test_ID_end (" << test_ID_end_
                << ") exceeds the days limit ("
                << forecasts.getSizeDim2()-1 << ")!" << RESET << std::endl;
        return false;
    }

    if (!(search_ID_end_ < test_ID_start_ || test_ID_end_ < search_ID_start_)) {
        std::cerr << BOLDRED << "ERROR: Training (" << search_ID_start_ << "~"
                << search_ID_end_ << ") overlaps with testing (" << test_ID_start_
                << "~" << test_ID_end_ << ")!" << RESET << std::endl;
        return false;
    }
    
    if (forecasts.getSizeDim1() != observations.getSizeDim1()) {
        std::cerr << BOLDRED << "ERROR: The numbers of stations in forecasts ("
            << forecasts.getSizeDim1() << ") and observations ("
            << observations.getSizeDim1() << ") do not match!"
            << RESET << std::endl;
        return false;
    }

    if (forecasts.getSizeDim2() != observations.getSizeDim2()) {
        std::cerr << BOLDRED << "ERROR: The numbers of days in forecasts "
                << "and observations do not match!" << RESET << std::endl;
        return false;
    }

    if (forecasts.getSizeDim3() != observations.getSizeDim3()) {
        std::cerr << BOLDRED
            << "ERROR: The numbers of forecasts lead times in forecasts "
                << "and observations do not match!" << RESET << std::endl;
        std::cerr << RED << "WARNING: This is only a temporary check!"
                << RESET << std::endl;
        return false;
    }

    if (weights_.size() != forecasts.getSizeDim0()) {
        std::cerr << BOLDRED << "ERROR: The number of weights do not "
                << "match the number of parameters in forecasts!" << RESET << std::endl;
        return false;
    }

    for (auto val : weights_) {
        if (val < 0) {
            std::cerr << BOLDRED << "ERROR: The parameter weights contains negative value ( " <<
                val << " )!" << RESET << std::endl;
            return false;
        }
    }

    if (observation_ID_ >= observations.getSizeDim0()) {
        std::cerr << BOLDRED << "ERROR: The observation_ID (" << observation_ID_ <<
            ") exceeds the limit of observations parameters (" << observations.getSizeDim0() - 1
            << ")!" << RESET << std::endl;
        return false;
    }

    size_t max_station_ID = *(std::max_element(main_stations_ID_.begin(), main_stations_ID_.end()));
    if (max_station_ID >= forecasts.getSizeDim1()) {
        std::cerr << BOLDRED << "ERROR: The station_ID (" <<
                max_station_ID << ") exceeds the station_ID limit ("
            << forecasts.getSizeDim1()-1 << ")!" << RESET << std::endl;
        return false;
    }

    if (search_ID_start_ > search_ID_end_) {
        std::cerr << BOLDRED << "ERROR: train_ID_start (" << search_ID_start_
                << ") is greater than train_ID_end limit (" << search_ID_end_ << ")!"
                << RESET << std::endl;
        return false;
    }

    if (search_ID_end_ >= forecasts.getSizeDim2()) {
        std::cerr << BOLDRED << "ERROR: train_ID_end (" << search_ID_end_
                << ") exceeds the days limit (" << forecasts.getSizeDim2()-1
                << ")!" << RESET << std::endl;
        return false;
    }

    size_t training_size = search_ID_end_ - search_ID_start_ + 1;
    if (rolling_ == 0) {
        if (training_size < members_size_) {
            std::cerr << BOLDRED << "ERROR: The number of members (" << members_size_ <<
                ") is larger than the number of training days (" << training_size
                << ")!" << RESET << std::endl;
            return false;
        }
    }

    if (rolling_ > 0) {
        std::cerr << BOLDRED << "ERROR: rolling (" << rolling_
                << ") should be 0 or negative!" << RESET << std::endl;
        return false;
    }

    if (num_cores_ == 0) {
        std::cerr << BOLDRED << "ERROR: num_cores should cannot be 0!" << RESET << std::endl;
        return false;
    }
    
    return true;
}
