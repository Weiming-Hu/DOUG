/* 
 * File:   Array2D.h
 * Author: Guido Cervone
 *         Weiming Hu
 *  */

#ifndef ARRAY2D_H
#define	ARRAY2D_H

#include <iostream>
#include <vector>

using namespace std;

/** GC:
 */
class Array2D : public vector < vector < double > > {
public:

    Array2D();
    Array2D(size_t, size_t);
    Array2D(const Array2D&);

    virtual ~Array2D();

    auto sizeM() const -> decltype(size()) { return( size() ); }
    auto sizeN() const -> decltype(begin()->size()) { return ( begin()->size()); }

    void randomize();
    
    void print_size(ostream &) const;
    void print(ostream &) const;
    void print_dim( ostream &, size_t ) const;
    friend ostream & operator<<(ostream &, Array2D const &);

    // overload the assignment operator
    // to avoid using vector swap function
    //
    Array2D& operator=(const Array2D &rhs);

    // attributes for sds Array2D
    std::size_t search_ID_end = 0;

private:

};

class Array2DCompare {
public:

    explicit Array2DCompare(size_t column);
    
    bool operator()(vector <double> const& lhs,
        vector <double> const& rhs);

private:
    size_t m_column_;
};


#endif	/* ARRAY2D_H */

