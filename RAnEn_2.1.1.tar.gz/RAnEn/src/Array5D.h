/*
 * Author: Weiming Hu
 *
 * Created on June 3, 2016
 *
 * This is the improved multi_array class of the Array4D class for holding
 * analogs results. A 4D array can only hold values for analogs results,
 * but a 5D array can hold both the values and the indices of each value,
 * which could be very helpful in the future.
 *
 * By default, the fifth dimension of the returned Array5D would have the
 * length of 3.
 *
 *      Array5D [station_ID][day_ID][FLT][member_ID][0] ---> value
 *      Array5D [station_ID][day_ID][FLT][member_ID][1] ---> station_ID
 *      Array5D [station_ID][day_ID][FLT][member_ID][2] ---> day_ID
 *
 */

#ifndef ARRAY5D_H
#define ARRAY5D_H

// code snippet for R interface
// Please don't remove
//
// [[Rcpp::depends(BH)]]
//
#include <boost/multi_array.hpp>
#include <iostream>
#include <string>

#include "Array2D.h"

class Array5D : public boost::multi_array<double, 5> {
public:
    Array5D();
    Array5D(const Array5D & rhs);
    Array5D(size_t num_stations,
            size_t num_days,
            size_t num_flts,
            size_t num_members,
            size_t num_returns);

    virtual ~Array5D();

    enum class Member {
        VAL = 0,
        STATION = 1,
        DAY = 2
    };

    bool reformat_array(Array5D & refmt, std::string type);

    bool set_xs(std::vector<double> input);
    bool set_ys(std::vector<double> input);

    std::ostream & print_search_stations(ostream& out);

    template<typename T>
    Array5D & operator=(const T & rhs) {
        boost::multi_array<double, 5>::operator=(rhs);
        return *this;
    }

    void print(std::ostream &) const;
    friend std::ostream & operator<<(std::ostream &, const Array5D &);

    std::vector<double> get_xs();

    std::vector<double> get_ys();

    bool empty_xs();

    bool empty_ys();

    size_t xs_size() const;

    size_t ys_size() const;

    bool set_search_stations(
            size_t main_station_index,
            const std::vector<size_t> & search_stations);

    bool set_metric(
            size_t main_station_index,
            size_t test_ID,
            size_t flt,
            const Array2D & metric);

    bool resize_vec_search_stations();

    const boost::multi_array<Array2D, 3> & get_const_metrics() const;

    const std::vector< std::vector<size_t> > & get_const_vec_search_stations() const;

    bool resize_metrics();

protected:
    // dimensions of the Array5D
    //
    size_t num_stations_ = 0;
    size_t num_days_ = 0;
    size_t num_flts_ = 0;
    size_t num_members_ = 0;
    size_t num_returns_ = 3;

private:
    // x and y of each station
    //
    std::vector<double> xs_;
    std::vector<double> ys_;

    // metrics for each station
    //
    // metrics[station][test day][flt]
    //
    boost::multi_array<Array2D, 3> metrics_;

    // extended search stations for each main station
    //
    std::vector< std::vector<size_t> > vec_search_stations_;

};

#endif
