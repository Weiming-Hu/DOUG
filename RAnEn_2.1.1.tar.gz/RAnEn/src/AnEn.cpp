/* 
 * File:   AnEn.cpp
 * Author: guido
 * 
 * Created on October 3, 2013, 9:22 PM
 */

#include "AnEn.h"

#ifdef _CAnEn_ONLY
#include "boost/filesystem/operations.hpp"
#include "ProgressBar.h"

#else
static int prog_bar = 0;
#endif



AnEn::AnEn() {
}

//AnEn::AnEn(const AnEn& orig) {
//}

AnEn::~AnEn() {
}

AnEn::AnEn(
        const std::vector<double>& weights, std::size_t observation_ID,
        const std::vector<std::size_t>& main_stations_ID,
        std::size_t test_ID_start, std::size_t test_ID_end,
        std::size_t search_ID_start, std::size_t search_ID_end,
        std::size_t members_size,
        int rolling, bool quick, std::size_t num_cores,
        bool search_extension,
        bool observation_from_extended_station,
        bool recompute_sd_for_extended_station,
        std::string output_metric)
: Ensemble(weights, observation_ID, main_stations_ID,
test_ID_start, test_ID_end,
search_ID_start, search_ID_end,
members_size, rolling, quick, num_cores) {
    // constructor with algorithm parameters
    // call the base constructor
    //
    search_extension_ = search_extension;
    output_metric_ = output_metric;

    if (search_extension) {
        observation_from_extended_station_ = observation_from_extended_station;
        recompute_sd_for_extended_station_ = recompute_sd_for_extended_station;
    }
}

Array5D
AnEn::computeAnalogs(
        const Array4D & forecasts,
        const Array4D & observations) const {

    // We need to add +1 because it is inclusive of the last day of the search 
    //
    auto search_size = search_ID_end_ - search_ID_start_ + 1;
    auto testing_size = test_ID_end_ - test_ID_start_ + 1;
    auto flt = forecasts.getSizeDim3();
    auto forecasts_parameter_size = forecasts.getSizeDim0();

    //cout << "flt: " << flt << std::endl
    int cores_stations = 0, cores_test_days = 0,
            parallel_level = 0;
    if (main_stations_ID_.size() < testing_size) {
        // if there are more test days
        // parallelize test days
        //
        cores_stations = 1;
        cores_test_days = num_cores_;
        parallel_level = 2;
    } else {
        // if there are more stations
        // parallelize stations
        //
        cores_stations = num_cores_;
        cores_test_days = 1;
        parallel_level = 1;
    }

    //    << "search_size: " << search_size << std::endl
    //    << "testing_size: " << testing_size << std::endl
    //    << "main_stations_ID_.size(): " << main_stations_ID_.size() << std::endl
    //    << "forecasts_parameter_size: " << forecasts_parameter_size << std::endl;

    // This is the substring that is used when computing the metric.
    // 1 means a size of 3, from -1..1
    //
    auto substring_size = 1;

    // Stores the standard deviation for the metric
    //
    Array2D sds(forecasts_parameter_size, flt);

    // This is the matrix that will keep the indexes for the results
    //
    Array5D analogs(main_stations_ID_.size(), testing_size, flt,
            members_size_, _fifth_dimension);

    if (output_metric_ == "inMemory") {
        try {
            analogs.resize_metrics();
        } catch (std::bad_alloc & e) {
            cerr << "Error: insufficient space to store all metrics in memory!"
                    << " Try output metrics to a folder!" << endl;
            return analogs;
        } catch (std::exception & e) {
            cerr << "Error: " << e.what() << endl;
            return analogs;
        }
    }

    if (save_search_stations_) {
        try {
            analogs.resize_vec_search_stations();
        } catch (std::bad_alloc & e) {
            cerr << "Error: insufficient memory to store search stations for "
                    << "all main stations!" << endl;
            return analogs;
        } catch (std::exception & e) {
            cerr << "Error: " << e.what() << endl;
            return analogs;
        }
    }

#ifdef _CAnEn_ONLY
    // progress bar
    ProgressBar prog_bar;
    prog_bar.start(main_stations_ID_.size() * testing_size);
#endif
    size_t count = 0;

    // loop through the all the stations
    //
#if defined(_OPENMP)
#pragma omp parallel for num_threads(cores_stations) default(none) schedule(static) \
    shared(observations, analogs, count, forecasts, prog_bar, flt, testing_size, substring_size, cout, cerr) \
    firstprivate(search_size, sds, parallel_level, cores_test_days)
#endif
    for (std::size_t main_station_index = 0;
            main_station_index < main_stations_ID_.size();
            main_station_index++) {

#ifdef _CAnEn_ONLY
        if (parallel_level == 1) {
            prog_bar.update(count);
        }
#endif

        auto main_station_ID = main_stations_ID_[ main_station_index ];

        //cout << "main_station_ID " << main_station_ID
        //    << " main_station_index " << main_station_index << std::endl;

        // initialize extended_stations_ID with main_station_ID
        // for the case that search extension is not chosen;
        // if search extension is chosen, call functions to 
        // generate the extended station ID vector
        //
        std::vector<size_t> extended_stations_ID{main_station_ID};
        if (search_extension_) {
            extended_stations_ID =
                    this->getStationExtension(forecasts, main_station_ID);
        }

        if (save_search_stations_) {
            analogs.set_search_stations(
                    main_station_index, extended_stations_ID);
        }

        // search_days_size is the product of training_size and the number of search stations
        // because that would be the total number of stations to be searched.
        // This takes the consideration of searching across stations
        //
        size_t search_days_size = search_size * extended_stations_ID.size();

        // For optimization we should compute SDs here,
        // so they are not computed each time in the metric.
        // This makes no difference if rolling is set,
        // because they have to be recomputed for each test day.
        //
        // Note that there might be a discrepancy in the code since the SD is computed
        // for all the search events, including those values that might be removed
        // in the computations because corresponding observations have NaN values
        //
        if (rolling_ >= 0) {
            sds.search_ID_end = search_ID_end_;
            this->computeSds_(forecasts, main_station_ID, sds);
            // cout << sds << endl;
        }

        // because all OMP clauses forbit any class private member 
        // I create a copy of search_ID_end_ which is a private member
        // In cases of rolling, this variable will get changed for
        // different test days. However, this should not affect
        // the AnEn object.
        //
        size_t search_ID_end_thread_private = search_ID_end_;

        // loop through all the testing days
        //
#if defined(_OPENMP)
#pragma omp parallel for num_threads(cores_test_days) default(none) schedule(static) \
        shared(analogs, observations, forecasts, prog_bar, flt, count, \
                main_station_index, testing_size, substring_size, cout, cerr) \
        firstprivate(search_ID_end_thread_private, search_size, sds, parallel_level, \
                extended_stations_ID, search_days_size, main_station_ID)
#endif
        for (std::size_t test_ID_index = 0;
                test_ID_index < testing_size; test_ID_index++) {

#ifdef _CAnEn_ONLY
            if (parallel_level == 2) {
                prog_bar.update(count);
            }
#endif
            // progress bar counter add 1
            count++;

            auto test_ID = test_ID_index + test_ID_start_;

            //cout << "From thread #" << omp_get_thread_num() << " out of "
            //    << omp_get_num_threads() << " threads." << endl;

            // the days for which we perform the analogs
            // we need to recompute the following variables
            // because they change for different test days
            //
            if (rolling_ < 0) {
                // The search are up to the current test ID (remember rolling is always negative)
                search_ID_end_thread_private = test_ID + rolling_;

                search_size = search_ID_end_thread_private - search_ID_start_ + 1;
                search_days_size = search_size * extended_stations_ID.size();

                sds.search_ID_end = search_ID_end_thread_private;
                this->computeSds_(forecasts, main_station_ID, sds);
            }

            // loop for all the FLT
            //
            for (int time = 0; time < static_cast<int> (flt); time++) {
                int begin_time = time - substring_size;
                int end_time = time + substring_size;

                // Make sure that we do not only have NAN values
                // There can be a problem if all values are NAN
                //
                bool valid = false;

                // Make sure we are within the boundaries
                //
                begin_time = (begin_time < 0) ? 0 : begin_time;
                end_time = (end_time == static_cast<int> (flt))
                        ? static_cast<int> (flt) - 1 : end_time;

                // The matrix that computes the error for each measure
                // 1st column: values
                // 2nd column: station ID
                // 3rd column: day ID
                //
                Array2D metric(search_days_size, 3);

                // the row of the array2D where 
                // member values, station ID, and day ID
                // will be assigned
                //
                std::size_t row_index = 0;

                // loop through all the search days
                //
                for (std::size_t search_ID_index = 0;
                        search_ID_index < search_size; search_ID_index++) {
                    auto search_ID = search_ID_index + search_ID_start_;

                    // loop throught all the extended stations
                    for (std::size_t extended_station_index = 0;
                            extended_station_index < extended_stations_ID.size();
                            extended_station_index++, row_index++) {
                        auto extended_station_ID = extended_stations_ID[extended_station_index];

                        bool ret = this->computeMetricSingle_(
                                forecasts, observations, sds,
                                main_station_ID, extended_station_ID,
                                search_ID, test_ID,
                                time, begin_time, end_time,
                                metric[row_index]);
                        valid = valid | ret;

                    } // end loop through extended stations
                } // end loop through search days


                // Now we need to sort the results and keep the members_size
                if (valid) {
//                    cout << "metric before sort from main station " << main_station_ID << " test_ID " << test_ID << " flt " << time << endl;
//                    cout << metric << endl;
                    
                    if (quick_) {
                        // find the least n elements, and put them in the front
                        // ATTENTION: the least n elements are not sorted
                        //
                        nth_element(metric.begin(), metric.begin() + members_size_,
                                metric.end(), Array2DCompare( _index_VAL ));
                    } else {
                        //partial_sort(metric.begin(), metric.begin() + members_size_, metric.end(), Array2DCompare(time));
                        sort(metric.begin(), metric.end(), Array2DCompare( _index_VAL ));                        
                    }
                    //cout << "metric after sort from main station " << main_station_ID << " test_ID " << test_ID << " flt " << time << endl;
                    //cout << metric << endl;
                    
                    if (!output_metric_.empty()) {
                        if (output_metric_ == "inMemory") {
                            analogs.set_metric(main_station_index, test_ID_index, time, metric);
#ifdef _CAnEn_ONLY
                        } else {
                            string metric_file = output_metric_ +
                                    "station_" + std::to_string(main_station_ID) +
                                    "_test_" + std::to_string(test_ID) +
                                    "_flt_" + std::to_string(time) + ".txt";
                            ofstream ofile(metric_file, ofstream::out);
                            ofile << "Station: " << main_station_ID << endl
                                    << "Test ID: " << test_ID << endl
                                    << "Forecast lead time: " << time << endl << endl;
                            ofile << metric << endl;
                            ofile.close();
#endif
                        }
                    }

                    // store the best members after they have been sorted
                    for (std::size_t metric_index = 0; metric_index < members_size_; metric_index++) {
                        
                        // the flt corresponds to the sorted indexes (the last column in the array)
                        // It is safe to cast into an int, because the last value is always an integer
                        // We need to add the search_ID_start_ because the indexes are relative to this
                        //
                        auto observation_station_index = metric[metric_index][ _index_STATION ];
                        auto observation_day_index = metric[metric_index][ _index_DAY ] + search_ID_start_;

                        // observations can be taken from the main station or the extended station
                        double observation;
                        if (observation_from_extended_station_) {
                            observation = observations[observation_ID_][observation_station_index][observation_day_index][time];
                        } else {
                            observation = observations[observation_ID_][main_station_ID][observation_day_index][time];
                        }
                        
                        // Assign the analog value corresponding to this metric index
                        analogs[main_station_index][test_ID_index][time][metric_index][_index_STATION] = observation_station_index;
                        analogs[main_station_index][test_ID_index][time][metric_index][_index_DAY] = observation_day_index;
                        analogs[main_station_index][test_ID_index][time][metric_index][_index_VAL] = observation;
                    }
                } else {
                    // If there are only NANs, set the analogs as all NAN
                    for (std::size_t metric_index = 0; metric_index < members_size_; metric_index++) {
                        analogs[main_station_index][test_ID_index][time][metric_index][_index_VAL] = NAN;
                        analogs[main_station_index][test_ID_index][time][metric_index][_index_DAY] = NAN;
                        analogs[main_station_index][test_ID_index][time][metric_index][_index_STATION] = NAN;
                    }
                }
            } // end loop through the flt
        } // end loop testing days
    } // end loop stations

    // progress bar final end line
    cout << endl;

    return (analogs);
}

// This method computes the metric for a single search/test day combination

bool
AnEn::computeMetricSingle_(
        Array4D const & forecasts,
        Array4D const & observations,
        Array2D sds, // no reference because it might need recomputing
        std::size_t main_station_ID,
        std::size_t extended_station_ID,
        std::size_t search_ID,
        std::size_t test_ID,
        int time, int begin_time, int end_time,
        std::vector<double> & metric) const {

    // This ensure that the metric was properly computed for this location
    bool valid = false;

    // Do not compute if the search and testing are the same
    if (search_ID != test_ID) {

        auto forecasts_parameter_size = forecasts.getSizeDim0();
        auto size = end_time - begin_time + 1;
        vector<double> window(size);

        // Get the corresponding observation
        //
        double observation = 0.0;
        if (extended_station_ID != main_station_ID) {
            // if the search station is different from the main station

            if (observation_from_extended_station_) {
                observation = observations[observation_ID_][extended_station_ID][search_ID][time];
            }

            if (recompute_sd_for_extended_station_) {
                // if we are computing the metric between forecasts of the main station and
                // a different search station, and if we choose to use the sd from the 
                // search station, we need to recompute the sd, rather to use the sd which
                // is passed in.
                //
                this->computeSds_(forecasts, extended_station_ID, sds);
            }

        } else {
            observation = observations[observation_ID_][main_station_ID][search_ID][time];
        }

        // loop through all the parameters
        //
        for (std::size_t parameter = 0; parameter < forecasts_parameter_size; parameter++) {

            // If the test forecast at the center (time) is NAN, do not compute analogs
            if (std::isnan(forecasts[parameter][main_station_ID][test_ID][time])) {
                metric[_index_VAL] = NAN;
                break;
            }

            // Get the data for this prediction
            //                            
            double forecast = forecasts[parameter][main_station_ID][search_ID][time];
            double weight = weights_[parameter];

            double sd = sds[parameter][time];
            

            // if weight is 0 we do not need to continue for this parameter
            if (weight != 0) {

                // Make sure that we have a good corresponding value in the
                // observations, otherwise skip the computation of the metric
                //                  
                // Also make sure that the no forecasts had NAN values
                // The analog can be NAN if the forecasts were missing for any other parameter
                //
                // Skip the computing process when the weight for this parameter is 0
                //
                if ((weight != 0) &&
                        !std::isnan(observation) &&
                        !std::isnan(forecast) &&
                        !std::isnan(metric[_index_VAL])) {

                    // compute the difference between the forecast and this ensemble member
                    //
                    std::size_t index;
                    for (auto i = begin_time, index = 0; i <= end_time; i++, index++) {

                        double search_value = forecasts[parameter][extended_station_ID][search_ID][i];
                        double test_value = forecasts[parameter][main_station_ID][test_ID][i];
                        
                        
//                        cout << "test_value " << test_value << " search_value " << search_value << endl;
//                        cout << "calculation: " << pow(search_value - test_value, 2) << endl;

                        // check if we need to do a circular difference
                        //
                        if (forecasts.isCircular(parameter)) {
                            window[index] = pow(Functions::diffCircular(search_value, test_value), 2);
                        } else {
                            window[index] = pow(search_value - test_value, 2);
                        }
                    } // end loop through the substring
                    
//                    cout << "window: ";
//                    for (auto & ele : window) {
//                        cout << ele << " ";
//                    }
//                    cout << endl;

                    double mean = Functions::mean(window);
//                    cout << "parameter " << parameter << " observation " << observation << " forecast " << forecast << " sd " << sd << " mean " << mean << endl;

                    // Make sure that the standard deviation is not zero
                    if (sd > 0) {
                        // assign the value
                        metric[_index_VAL] += weight * ((sqrt(mean) / sd)); 
//                        cout << "metric " << metric[_AnEn_Member_VAL_] << endl;
                                
                        valid = true;
                    }

                } else { // this means that the corresponding observation or forecast has a NaN value
                    metric[_index_VAL] = NAN;
                }
            }

        } // end loop through parameters

    } else {
        // if search_ID and test_ID are the same
        // Set to no value for all the flt
        //
        metric[_index_VAL] = NAN;
    } // Make sure there is a valid observation

    if (!std::isnan(metric[_index_VAL])) {
        metric[_index_STATION] = extended_station_ID;
        metric[_index_DAY] = search_ID;
    }

    return valid;
}

bool
AnEn::computeSds_(
        const Array4D & forecasts,
        const std::size_t & main_station_ID,
        Array2D & sds) const {
    int flt = forecasts.getSizeDim3();
    int forecasts_parameter_size = forecasts.getSizeDim0();

    for (int parameter = 0; parameter < forecasts_parameter_size; parameter++) {
        for (int time = 0; time < flt; time++) {
            sds[parameter][time] = Functions::computeSdDim3(
                    forecasts, parameter, main_station_ID,
                    search_ID_start_, sds.search_ID_end, time);
        }
    }

    return true;
}

std::vector<size_t>
AnEn::getStationExtension(
        const Array4D & array,
        const size_t & main_station_ID) const {

    // NOTE:
    // extended_stations_ID = 
    //     search_stations_ID + main_station_ID
    //     (conceptually, not actually in C++ grammar!)
    //
    vector<size_t> search_stations_ID(array.xs_size());

    if (array.empty_xs() || array.empty_ys()) {
        cout << "Warning: xs and ys variables missing in the array! "
                << " Search extension ignored!" << endl;
        return {main_station_ID};
    }

    // the initialized search stations ID include all the IDs
    // but the main station ID
    //
    iota(search_stations_ID.begin(), search_stations_ID.end(), 0);
    search_stations_ID.erase(search_stations_ID.begin() + main_station_ID);

    if (num_nearest_ != 0) {
        // select the closest num_nearest stations
        //
        vector<size_t> stations_buffer(search_stations_ID);

        // get the range of xs and ys
        double xs_range = array.xs_max() - array.xs_min();
        double ys_range = array.ys_max() - array.ys_min();

        // initialize edge
        double edge = 0.0, init_factor = 2, growth = 1.5;
        if (xs_range > ys_range) {
            edge = ys_range * num_nearest_ * init_factor / array.ys_size();
        } else {
            edge = xs_range * num_nearest_ * init_factor / array.xs_size();
        }

        // loop and increase the edge until we find enough 
        // stations within the square to proceed to nearest neighbor
        //
        // by doing this, we don't need to compute every distance pair
        //
        bool not_enough_stations = true;
        while (not_enough_stations) {

            this->select_stations_within_square(array, main_station_ID,
                    stations_buffer, edge);
            //cout << "number of stations found: " << stations_buffer.size() << endl;

            if (stations_buffer.size() >= num_nearest_) {
                not_enough_stations = false;
            } else {
                stations_buffer.resize(search_stations_ID.size());
                copy(search_stations_ID.begin(),
                        search_stations_ID.end(),
                        stations_buffer.begin());
                edge *= growth;
            }
        }

        if (stations_buffer.size() != num_nearest_) {
            this->select_nearest_stations(
                    array, main_station_ID, stations_buffer);
        }

        search_stations_ID = stations_buffer;

        if (distance_ != 0) {
            this->select_stations_within_distance(
                    array, main_station_ID, search_stations_ID);
        }

    } else {
        if (distance_ != 0.0) {
            // select stations within the distance
            //

            this->select_stations_within_square(
                    array, main_station_ID, search_stations_ID, 2 * distance_);
            this->select_stations_within_distance(
                    array, main_station_ID, search_stations_ID);
        } else {
            cout << "Warning: both distance and number of neighbors have"
                    << " not been set! Search extension ignored!" << endl;
            return {main_station_ID};
        }
    }

    search_stations_ID.push_back(main_station_ID);

    return search_stations_ID;
}

bool
AnEn::select_stations_within_distance(
        const Array4D & array,
        const size_t & main_station_ID,
        vector<size_t> & search_stations_ID) const {
    const vector<double> & xs = array.get_xs();
    const vector<double> & ys = array.get_ys();

    // compute distances from the main station to each
    // of the station in search stations
    //
    map<size_t, double> distance_map;
    double dummy_distance;
    for (size_t i = 0; i < search_stations_ID.size(); i++) {
        dummy_distance =
                pow(xs[main_station_ID] - xs[search_stations_ID[i]], 2) +
                pow(ys[main_station_ID] - ys[search_stations_ID[i]], 2);
        distance_map.insert(make_pair(search_stations_ID[i], dummy_distance));

        //cout << "sqaured distance to search station " << search_stations_ID[i]
        //    << "(" << xs[search_stations_ID[i]] << "," << ys[search_stations_ID[i]]
        //    << ") is " << dummy_distance << endl;
    }

    // square the distance to avoid computing root square
    // of each distance in the map
    //
    double distance_squred = distance_ * distance_;

    // remove search stations that have a larger distance
    // to the main station
    //
    search_stations_ID.erase(
            std::remove_if(
            search_stations_ID.begin(),
            search_stations_ID.end(),
            [distance_squred, &distance_map]
            (size_t ID) {
                return (distance_map[ID] > distance_squred);
            }), search_stations_ID.end());

    return true;
}

bool
AnEn::select_stations_within_square(
        const Array4D & array,
        const size_t & main_station_ID,
        vector<size_t> & search_stations_ID,
        const double & edge) const {
    const vector<double> & xs = array.get_xs();
    const vector<double> & ys = array.get_ys();

    //cout << "for main station " << main_station_ID << "("
    //    << xs[main_station_ID] << "," << ys[main_station_ID]
    //    << ") with an edge " << edge << endl;

    double x_upper = xs[main_station_ID] + edge / 2;
    double x_lower = xs[main_station_ID] - edge / 2;
    double y_upper = ys[main_station_ID] + edge / 2;
    double y_lower = ys[main_station_ID] - edge / 2;

    //cout << "inside squre function:" << endl
    //    << "x range : " << x_lower << "~" << x_upper << endl
    //    << "y range : " << y_lower << "~" << y_upper << endl;

    // remove the stations from search stations if
    // the x and y of the stations exceed the
    // lower/upper bounds
    //
    search_stations_ID.erase(
            std::remove_if(
            search_stations_ID.begin(),
            search_stations_ID.end(),
            [&xs, &ys, x_upper, y_upper, x_lower, y_lower]
            (size_t id) {
                double x = xs[id];
                double y = ys[id];
                bool ret =
                        (x_lower > x) || (x > x_upper) ||
                        (y_lower > y) || (y > y_upper);
                //cout << "Point " << x << "," << y << ": " << ret << endl;
                return ret;
            }), search_stations_ID.end());

    return true;
}

bool
AnEn::select_nearest_stations(
        const Array4D & array,
        const size_t & main_station_ID,
        vector<size_t> & search_stations_ID) const {
    const vector<double> & xs = array.get_xs();
    const vector<double> & ys = array.get_ys();

    if (search_stations_ID.size() <= num_nearest_) {
        return true;
    }

    // compute distances from the main station to each
    // of the station in search stations
    //
    vector<double> distances_squared(search_stations_ID.size());
    for (size_t i = 0; i < distances_squared.size(); i++) {
        distances_squared[i] =
                pow(xs[main_station_ID] - xs[search_stations_ID[i]], 2) +
                pow(ys[main_station_ID] - ys[search_stations_ID[i]], 2);

        //cout << "sqaured distance to search station " << search_stations_ID[i]
        //    << "(" << xs[search_stations_ID[i]] << "," << ys[search_stations_ID[i]]
        //    << ") is " << distances_squared[i] << endl;
    }

    // select the closest num_nearest stations
    vector< pair<double, size_t> > pairs;
    transform(distances_squared.begin(), distances_squared.end(),
            search_stations_ID.begin(), inserter(pairs, pairs.end()),
            make_pair<const double &, const size_t &>);

    sort(pairs.begin(), pairs.end());

    //cout << "Sorted:" << endl;
    //for (auto i : pairs) {
    //    cout << i.first << " " << i.second << endl;
    //}
    //cout << endl;

    search_stations_ID.resize(num_nearest_);
    for (size_t i = 0; i < num_nearest_; i++) {
        search_stations_ID.at(i) = pairs[i].second;
    }

    return true;
}

bool
AnEn::validate_parameters(
        const Array4D & forecasts,
        const Array4D & observations) const {

    // validate base class member variables
    if (!Ensemble::validate_parameters(
            forecasts, observations)) {
        return false;
    }

    // validate class member variables
#ifdef _CAnEn_ONLY
    if (!output_metric_.empty()) {
        namespace fs = boost::filesystem;

        fs::path output_metric(output_metric_);

        if (!fs::is_directory(output_metric)) {
            std::cerr << "folder " << output_metric_ << "not found!";
            return false;
        }
    }
#endif

    if (!search_extension_) {
        // search extension is not used
        if (observation_from_extended_station_) {
            std::cout << RED << "observation_from_extended_station_ cannot be set "
                    << "when search extension is NOT used!" << RESET << std::endl;
            return false;
        }

        if (recompute_sd_for_extended_station_) {
            std::cout << RED << "recompute_sd_for_extended_station_ cannot be set "
                    << "when search extension is NOT used!" << RESET << std::endl;
            return false;
        }
    } else {
        // search extension is used
        if (distance_ == 0.0 && num_nearest_ == 0) {
            std::cout << "Both of the variables distance and num_nearest"
                    << " are not set for search extension!" << std::endl;
            std::cout << RED << "Search Extension ignored!" << RESET << std::endl;
        }

        if (num_nearest_ > forecasts.getSizeDim1() - 1) {
            // if you are requesting more stations than there are
            //
            cerr << "Error: Too many neighbor search stations required."
                    << "The max is " << forecasts.getSizeDim1() - 1 << "!" << endl;
            return false;
        }
    }

    return true;
}

bool
AnEn::switch_observation_from_extended_station(bool b) {
    if (search_extension_) {
        observation_from_extended_station_ = b;
        return true;
    } else {
        return false;
    }
}

bool
AnEn::switch_save_search_stations(bool input) {
    save_search_stations_ = input;
    return true;
}

bool
AnEn::switch_recompute_sd_for_extended_station(bool b) {
    if (search_extension_) {
        recompute_sd_for_extended_station_ = b;
        return true;
    } else {
        return false;
    }
}

bool
AnEn::switch_search_extension(bool b) {
    search_extension_ = b;
    return true;
}

bool
AnEn::set_output_metric(string input) {
    output_metric_ = input;
    return true;
}

bool
AnEn::set_distance(double input) {
    distance_ = input;
    return true;
}

bool
AnEn::set_num_nearest(size_t input) {
    num_nearest_ = input;
    return true;
}

double
AnEn::get_distance() {
    return distance_;
}

size_t
AnEn::get_num_nearest() {
    return num_nearest_;
}
